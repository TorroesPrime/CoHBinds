name= input("please eneter a name for this bind set. No spaces.")
file_name = input("please enter the file name you wish to convert to binds")
increment = 1
control = "F10 "
channel = "\"L "
slash = "\\"
set_name =name+slash
load_next = " $$bind_load_file C:\\binds\stupids\\"
with open(str(file_name)) as f:
    for line in f.readlines():
        outputName = "0"+str(increment)+".txt"
        output = open(outputName,"w")
        e = line.strip('\n')
        line = control+channel+e+load_next+set_name+"0"+str(increment+1)+".txt\""
        increment +=1
        output.write(line)
        output.close()      
f.close()
